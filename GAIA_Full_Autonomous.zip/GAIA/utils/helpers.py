# Placeholder for helper functions
