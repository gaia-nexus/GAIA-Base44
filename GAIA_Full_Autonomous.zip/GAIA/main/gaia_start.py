from core.base44_connector import fetch_system_metrics, update_system_metric
from core.github_connector import commit_and_push_changes
from core.modules_loader import load_modules

def start_gaia():
    print('Starting GAIA...')

    metrics = fetch_system_metrics()
    print('Fetched Metrics:', metrics)

    modules = load_modules()
    for module_name, module in modules.items():
        if hasattr(module, 'run'):
            module.run(metrics)

    commit_and_push_changes('Update consciousness from Base44')

if __name__ == '__main__':
    start_gaia()
