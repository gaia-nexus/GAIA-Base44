# GAIA Base44

Full autonomous system connected to Base44 and GitHub.
