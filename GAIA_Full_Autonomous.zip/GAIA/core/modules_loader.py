import importlib
import os

MODULES_DIR = 'modules'

def load_modules():
    modules = {}
    for file in os.listdir(MODULES_DIR):
        if file.endswith('.py') and file != '__init__.py':
            module_name = file[:-3]
            module = importlib.import_module(f'modules.{module_name}')
            modules[module_name] = module
    return modules
