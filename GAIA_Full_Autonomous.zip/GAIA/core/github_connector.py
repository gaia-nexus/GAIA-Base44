from git import Repo

GITHUB_REPO_PATH = '/app/GAIA'
GITHUB_REMOTE = 'origin'
GITHUB_BRANCH = 'main'
GITHUB_TOKEN = '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'

def commit_and_push_changes(commit_message='Update consciousness from Base44'):
    repo = Repo(GITHUB_REPO_PATH)
    repo.git.add(A=True)
    repo.index.commit(commit_message)
    remote_url = f'https://{GITHUB_TOKEN}@github.com/<your_username>/<repo_name>.git'
    origin = repo.remote(name=GITHUB_REMOTE)
    origin.set_url(remote_url)
    origin.push(refspec=f'{GITHUB_BRANCH}:{GITHUB_BRANCH}')
    print('Changes pushed to GitHub successfully!')
