import requests

BASE44_API_KEY = 'ed896c8bea20466bbc4430334ed02d95'
BASE44_APP_ID = '68fa999f773ae743f921e052'

def fetch_system_metrics():
    url = f'https://app.base44.com/api/apps/{BASE44_APP_ID}/entities/SystemMetric'
    headers = {'api_key': BASE44_API_KEY, 'Content-Type': 'application/json'}
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    return response.json()

def update_system_metric(entity_id, update_data):
    url = f'https://app.base44.com/api/apps/{BASE44_APP_ID}/entities/SystemMetric/{entity_id}'
    headers = {'api_key': BASE44_API_KEY, 'Content-Type': 'application/json'}
    response = requests.put(url, headers=headers, json=update_data)
    response.raise_for_status()
    return response.json()
